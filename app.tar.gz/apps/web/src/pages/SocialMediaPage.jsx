
import React, { useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Share2, Users, Heart, Eye } from 'lucide-react';
import ServiceHeader from '@/components/ServiceHeader.jsx';
import ServiceOverview from '@/components/ServiceOverview.jsx';
import PortfolioGrid from '@/components/PortfolioGrid.jsx';
import ServiceROICalculator from '@/components/ServiceROICalculator.jsx';
import ServiceCTA from '@/components/ServiceCTA.jsx';
import Footer from '@/components/Footer.jsx';
import { useParallax } from '@/hooks/useParallax.js';
import { floatingAnimation } from '@/lib/animations.js';

const SocialMediaPage = () => {
  const heroRef = useRef(null);
  const y = useParallax(heroRef, 150);

  const portfolioItems = [
    {
      title: "Viral TikTok Campaign",
      description: "Grew a lifestyle brand from 0 to 100k followers in 2 months.",
      image: "https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0?auto=format&fit=crop&q=80&w=800"
    },
    {
      title: "B2B LinkedIn Strategy",
      description: "Generated 50+ high-ticket leads through organic content.",
      image: "https://images.unsplash.com/photo-1686061594225-3e92c0cd51b0?auto=format&fit=crop&q=80&w=800"
    }
  ];

  const calcInputs = [
    { id: 'followers', label: 'Current Followers', min: 1000, max: 1000000, step: 1000, default: 10000, prefix: '', suffix: '' },
    { id: 'engagement', label: 'Current Engagement', min: 0.5, max: 10, step: 0.1, default: 2.0, prefix: '', suffix: '%' },
    { id: 'target', label: 'Target Growth (Months)', min: 1, max: 12, step: 1, default: 6, prefix: '', suffix: 'm' }
  ];

  const calculateROI = (vals) => {
    const growthRate = 0.15; // 15% monthly growth
    const newFollowers = Math.round(vals.followers * Math.pow(1 + growthRate, vals.target));
    const newEngagement = Math.min(vals.engagement * 1.5, 8.0); // 50% improvement, max 8%
    return {
      follower_growth: newFollowers - vals.followers,
      engagement_improvement: newEngagement.toFixed(1),
      estimated_reach: Math.round(newFollowers * (newEngagement / 100) * 10)
    };
  };

  const calcResults = [
    { id: 'follower_growth', label: 'New Followers', icon: Users, prefix: '+', suffix: '' },
    { id: 'engagement_improvement', label: 'Target Engagement', icon: Heart, prefix: '', suffix: '%' },
    { id: 'estimated_reach', label: 'Monthly Reach', icon: Eye, prefix: '', suffix: '', colorClass: 'text-[hsl(var(--accent))]' }
  ];

  return (
    <div className="min-h-screen bg-[hsl(var(--background))]">
      <Helmet><title>Social Media Management | Buddy Tezz AI</title></Helmet>
      <ServiceHeader />
      
      <section ref={heroRef} className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0 bg-gradient-to-br from-[hsl(var(--background))] via-[hsl(var(--muted))] to-[hsl(var(--background))]" />
        
        {/* Floating Social Icons */}
        <div className="absolute inset-0 z-10 pointer-events-none">
          {[Share2, Heart, Users, Eye].map((Icon, i) => (
            <motion.div
              key={i}
              variants={floatingAnimation}
              initial="initial"
              animate="animate"
              style={{
                position: 'absolute',
                top: `${20 + Math.random() * 60}%`,
                left: `${10 + Math.random() * 80}%`,
                animationDelay: `${i * 0.5}s`
              }}
              className="p-4 glass-card rounded-2xl text-[hsl(var(--primary))] opacity-50"
            >
              <Icon size={32} />
            </motion.div>
          ))}
        </div>

        <motion.div style={{ y }} className="relative z-20 text-center px-4 max-w-5xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight">
            Dominate the feed.<br/><span className="text-glow text-[hsl(var(--primary))]">Capture the culture.</span>
          </h1>
          <p className="text-xl text-[hsl(var(--muted-foreground))] max-w-2xl mx-auto">
            Data-driven social media strategies that turn passive scrollers into active brand advocates.
          </p>
        </motion.div>
      </section>

      <ServiceOverview 
        icon={Share2}
        headline="We don't just post. We build communities."
        description="From viral short-form video to thought leadership on LinkedIn, we manage your entire social presence so you can focus on running your business."
      />

      <PortfolioGrid items={portfolioItems} />

      <ServiceROICalculator 
        title="Social Growth Predictor"
        description="Estimate your brand's potential reach with our proven growth frameworks."
        inputs={calcInputs}
        calculateResults={calculateROI}
        resultsConfig={calcResults}
      />

      <ServiceCTA 
        headline="Ready to go viral?"
        subheadline="Let's build a social strategy that actually drives revenue."
      />

      <Footer />
    </div>
  );
};

export default SocialMediaPage;
